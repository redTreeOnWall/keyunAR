
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 状态机事件监听
 */
public class StateEventListner {

    /**
     * 状态机事件监听
     */
    public StateEventListner() {
    }

}