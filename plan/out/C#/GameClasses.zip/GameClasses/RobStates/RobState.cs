
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobStates{
    /**
     * 小人状态机
     */
    public class RobState : BaseState {

        /**
         * 小人状态机
         */
        public RobState() {
        }

    }
}