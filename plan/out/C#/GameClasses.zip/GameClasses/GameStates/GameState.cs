
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameStates{
    /**
     * 游戏状态机
     */
    public abstract class GameState : BaseState {

        /**
         * 游戏状态机
         */
        public GameState() {
        }

    }
}